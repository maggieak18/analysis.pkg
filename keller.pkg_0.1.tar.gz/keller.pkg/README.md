# keller.pkg
## An R package for processing feeding behavioral data of Xenopus laevis

A package to analyze and process presence absence type behavioral
data. Specifically, ethogram based behavioral data of Xenopus laevis, whose
sensory system inputs have been manipulated.
