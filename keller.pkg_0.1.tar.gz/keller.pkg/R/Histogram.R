#This function will make histogram plots. This is where I will need to insert
#instructions on how to do the count code since we realized writing a function
#for that is not feasible.